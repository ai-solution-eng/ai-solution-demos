{{- define "donna.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{- define "donna.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{- define "donna.vendorLabelKey" -}}
{{- .Values.pcai.kyverno.vendor_service_label_key | default "hpe-ezua/type" -}}
{{- end -}}

{{- define "donna.vendorLabelValue" -}}
{{- .Values.pcai.kyverno.vendor_service_label_value | default "vendor-service" -}}
{{- end -}}

{{- define "donna.labels" -}}
app.kubernetes.io/name: {{ include "donna.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{ include "donna.vendorLabelKey" . }}: {{ include "donna.vendorLabelValue" . | quote }}
{{- end -}}

{{- define "donna.image" -}}
{{- $registry := .root.Values.pcai.image_registry | default "" -}}
{{- $name := .name -}}
{{- $tag := .root.Values.pcai.image_tag | default .root.Chart.AppVersion -}}
{{- if $registry -}}
{{- printf "%s/%s:%s" $registry $name $tag -}}
{{- else -}}
{{- printf "%s:%s" $name $tag -}}
{{- end -}}
{{- end -}}

{{- define "donna.serviceAccountName" -}}
{{- include "donna.fullname" . -}}
{{- end -}}
